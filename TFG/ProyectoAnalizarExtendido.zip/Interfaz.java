package paquete;

public interface Interfaz {
	public void fInterfaz();
}
