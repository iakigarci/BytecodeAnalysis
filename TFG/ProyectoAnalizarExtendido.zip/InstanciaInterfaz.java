package paquete;

public class InstanciaInterfaz implements Interfaz {

	public InstanciaInterfaz() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void fInterfaz() {
		Tercero t = new Tercero();
		t.f8();
		System.out.println(ClaseEnum.HIGH);
	}

}
