package paquete;

import java.util.ArrayList;

public class Segundo {

	ArrayList<Object> l = new ArrayList<>();
	
	public Segundo() {
		l.add(1);
		
	}
	
	public ArrayList<Object> getList() {
		return l;
	}
	
	@Override
	public String toString() {
		System.out.println("Soy una lista");
		return super.toString();
	}
}
