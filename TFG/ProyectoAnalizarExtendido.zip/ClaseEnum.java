package paquete;

public enum ClaseEnum {
	LOW,
	MEDIUM,
	HIGH
}
