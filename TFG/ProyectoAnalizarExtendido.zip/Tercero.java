package paquete;

public class Tercero {

	public Tercero() {
		f5();
	}
	
	public void f5() {
		System.out.println("Soy f5");
		f6();
	}
	
	public void f6() {
		System.out.println("Soy f6");
		f7();
	}
	
	public void f7() {
		System.out.println("Soy f7");
		f8();
	}
	
	public void f8() {
		System.out.println("Soy f8");
	}
}
