package paquete;

public class InstanciaAbstracta extends ClaseAbstracta {

	public InstanciaAbstracta() {
		// TODO Auto-generated constructor stub
	}

	@Override
	void siOverride() {
		noOverride();
		Tercero t = new Tercero();
		t.f8();
	}

}
