package paquete;

import java.util.ArrayList;


public class Main {

	public Main() {
		System.out.println("Hola buenas");
		f1();
	}
	
	public static void main(String[] args) {
		System.out.println("Hola soy el main de MAIN");
		f1();
		Tercero t = new Tercero();
		t.f5();
	}
	
	private static void f1() {
		f2();
		System.out.println("Hola soy f1");
		Segundo s = new Segundo();
		ArrayList<Object> l = s.getList();
		System.out.println(l);
	}
	
	private static void f2() {
		System.out.println("Soy f2");
	}
}
