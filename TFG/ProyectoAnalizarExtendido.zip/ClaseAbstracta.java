package paquete;

public abstract class ClaseAbstracta {

	public void noOverride() {
		int a = 2+1;
		System.out.println(a);
		Tercero t = new Tercero();
		t.f8();
	}
	
	abstract void siOverride();
}
