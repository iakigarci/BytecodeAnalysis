package callgraph;

public enum TraversalEnum {
    PRE_ORDER,
    POST_ORDER
}
